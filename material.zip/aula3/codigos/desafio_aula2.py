#x2 +3x–4=0
a = 1
b = 3
c = -4

delta = (b ** 2) - 4 * a * c

x1 = (-b + delta ** (1 / 2)) / (2 * a)
x2 = (-b - delta ** (1 / 2)) / (2 * a)

print(x1, x2)