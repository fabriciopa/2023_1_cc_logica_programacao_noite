#slide41
numero = input("Digite um número: ")
numero = int(numero)
numero = numero - 1
print(numero)