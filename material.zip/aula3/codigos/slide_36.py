#slide36
nome = input("Digite seu nome")
print(nome)