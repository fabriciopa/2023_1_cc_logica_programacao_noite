#slide38
num1 = input("Digite o primeiro número: ")
num2 = input("Digite o segundo número: ")
int_num1 = int(num1)
int_num2 = int(num2)
soma = int_num1 + int_num2
print(soma)