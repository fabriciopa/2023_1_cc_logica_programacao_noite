#slide40
a = 10
b = 20
aux_a = a
a = b
b = aux_a
print(a)
print(b)