#slide 15
nome = "Gabriel"
idade = 33
altura = 1.75

print(nome)
print(idade)
print(altura)