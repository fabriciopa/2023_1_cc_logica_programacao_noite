#slide 29
resultado = 25 + 60
print(resultado)

resultado = "25" + "60"
print(resultado)

resultado = "Fabricio" + "Araujo"
print(resultado)