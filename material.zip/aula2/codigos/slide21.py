#slide 21
x = 14
y = 62

#soma
soma = x + y
print(soma)

#subtração
subtracao = x - y
print(subtracao)

#multiplicação
multiplicacao = x * y
print(multiplicacao)

#divisão
divisao = x / y
print(divisao)

#modulo
modulo = x % y
print(modulo)

#divisão inteira
div_int = x // y
print(div_int)

#exponenciação
exponenciacao = x ** y
print(exponenciacao)