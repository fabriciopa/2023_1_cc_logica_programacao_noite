lista = [5,10,7,5]

print(lista)

