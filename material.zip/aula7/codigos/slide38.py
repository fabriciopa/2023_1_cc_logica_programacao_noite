numeros = list(range(101))
soma = 0
index = 0

while index < len(numeros):
    soma = soma + numeros[index]
    index = index + 1

print(soma)

