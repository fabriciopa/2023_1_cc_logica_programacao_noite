repeticoes = 1000

while repeticoes > 0:
    print("Olá, mundo!")
    repeticoes = repeticoes - 1

    