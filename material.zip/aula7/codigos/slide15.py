soma = 0
numeros = 0

while numeros <= 100:
    soma = soma + numeros

print(soma)

