nota1 = 5
nota2 = 10
nota3 = 7
nota4 = 5

