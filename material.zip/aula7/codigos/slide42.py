numeros = list(range(101))
soma = 0

for index in numeros:
    soma = soma + numeros[index]

print(soma)

