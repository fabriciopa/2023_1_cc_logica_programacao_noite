soma = 0
numeros = 0

while numeros <= 100:
    soma = soma + numeros
    numeros = numeros + 1

print(soma)

