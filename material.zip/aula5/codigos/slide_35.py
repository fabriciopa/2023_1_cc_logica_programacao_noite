n1 = input("Digite um número: ")
n1 = float(n1)

n2 = input("Digite outro número: ")
n2 = float(n2)

if n1 > n2:
    print(str(n1)+" é maior que "+str(n2))
else:
    print(str(n2)+" é maior que "+str(n1))