x = 59
y = 102
print(x > y)
print(x < y)
print(x >= y)
print(x <= y)
print(x == y)
print(x != y)