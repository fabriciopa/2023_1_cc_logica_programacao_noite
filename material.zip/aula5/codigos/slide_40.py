n1 = input("Digite um número: ")
n1 = float(n1)

if n1 > 0:
    print(str(n1)+" é positivo")
elif n1 == 0:
    print(str(n1)+" não é positivo nem negativo")
else:
    print(str(n1)+" é negativo")

    