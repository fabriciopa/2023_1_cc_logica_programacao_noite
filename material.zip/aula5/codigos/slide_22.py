x = 15
y = 10
print(x == 15 or y != 10)
print(x >= 15 and not y != 10)
print(x != 10 and y != 15 or x >= 15 or y < 20)
print(x > 20 and y == 10 or x != 15 and not x > 10)