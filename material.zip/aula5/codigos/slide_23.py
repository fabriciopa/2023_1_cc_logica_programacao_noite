print(False or ( 10 % 5 * 2 != 5 * 2 + 1 ))
print(not False and ( 3 * 3 / 3 < 15 - 5 % 7))
print(((34 < 9) and (5 + 29 == 34)) or ((5 == 15/3) and (8 > 12)))