idade = input("Digite a sua idade: ")
idade = int(idade)
if idade >= 18:
    print("Você já pode tirar a carteira de motorista")
else:
    print("Você ainda não pode tirar a carteira de motorista")