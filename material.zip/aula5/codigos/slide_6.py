booleana = True
print(booleana)