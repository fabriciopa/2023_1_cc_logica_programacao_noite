nome = "Fabricio"
idade = 37
print(nome != "Pedro" and idade < 40)