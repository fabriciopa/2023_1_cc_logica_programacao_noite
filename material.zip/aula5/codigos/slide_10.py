print(2 > 5)

salario = 10000
print(salario < 5000)

idade = 23
print(idade >= 18)

nome = "Fabricio"
print(nome != "João")

nota = 10
print(nota == 10)