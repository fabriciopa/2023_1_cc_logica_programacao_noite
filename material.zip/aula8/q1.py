numeros = 1

while numeros <= 20:
    print(numeros)
    numeros = numeros + 1

numeros = 1

while numeros <= 20:
    print(numeros, end=" ")
    numeros = numeros + 1