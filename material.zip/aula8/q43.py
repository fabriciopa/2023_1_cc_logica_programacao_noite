numero = input("Digite um número: ")

index = len(numero) - 1

while index >= 0:
    print(numero[index], end="")
    index = index - 1