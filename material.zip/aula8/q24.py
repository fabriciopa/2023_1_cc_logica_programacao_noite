total = 0

for i in range(50):
    total = total + 1.99
    print(str(i + 1) + " - R$ "+str(total))