contador = 1

while contador <= 50:
    if contador % 2 != 0:
        print(contador)
    contador = contador + 1