letra = input("Digite uma letra: ")

if letra == "a" or letra == "e" or letra == "i" or letra == "o" or letra == "u":
    print("Você digitou uma vogal")
else:
    print("Você digitou uma consoante")