num = input("Digite um número: ")
num = int(num)

if num % 2 == 0:
    print(str(num) + " é par")
else:
    print(str(num) + " é impar")