"""
2.	Faça um Programa que peça um número e então mostre a mensagem O número informado foi [número].
"""
numero = input("Digite um número: ")

print("O número informado foi "+numero)