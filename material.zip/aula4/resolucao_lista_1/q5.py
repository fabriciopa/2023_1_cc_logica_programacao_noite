"""
5.	Faça um Programa que converta metros para centímetros.
"""
metros = input("Digite o valor em metros: ")
metros = float(metros)

cent = metros * 100

print(cent)