"""
4.	Faça um Programa que peça as 4 notas bimestrais e mostre a média.
"""
n1 = input("Digite a primeira nota: ")
n2 = input("Digite a segunda nota: ")
n3 = input("Digite a terceira nota: ")
n4 = input("Digite a quarta nota: ")

n1 = float(n1)
n2 = float(n2)
n3 = float(n3)
n4 = float(n4)

media = (n1 + n2 + n3 + n4) / 4

print(media)