"""
3.	Faça um Programa que peça dois números e imprima a soma.
"""
x = input("Digite o primeiro número: ")
y = input("Digite o segundo número: ")

x = int(x)
y = int(y)
soma = x + y

print(soma)
