"""
6.	Faça um Programa que peça o raio de um círculo, calcule e mostre sua área.
"""
raio = input("Digite o valor raio: ")
raio = int(raio)
pi = 3.14
area = pi * (raio ** 2)
print(area)